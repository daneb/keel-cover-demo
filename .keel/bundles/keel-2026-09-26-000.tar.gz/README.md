# keel evidence bundle — run 2026-09-26-000

Spec `farewell`, driver `none`, keel 0.10.1.
Started 2026-09-26T10:24:38.098766627+00:00, finished 2026-09-26T10:24:38.427815609+00:00.

Base commit `33286299aa95157695c199049797af37a68da747`.

## What changed

```
     -      -  .keel/bundles/keel-2026-09-26-000.tar.gz
     4      0  .keel/chain.jsonl
     1      1  .keel/keel.toml
     4      0  .keel/lesson-usage.json
     2      0  .keel/runs/2026-09-26-000/evidence/build.txt
     2      0  .keel/runs/2026-09-26-000/evidence/lint.txt
    17      0  .keel/runs/2026-09-26-000/evidence/oracles.json
     2      0  .keel/runs/2026-09-26-000/evidence/test.txt
     9      0  .keel/runs/2026-09-26-000/run.json
     9      0  .keel/runs/2026-09-26-000/trajectory.jsonl
     2      0  .keel/specs/farewell/approvals.jsonl
    90      0  .keel/specs/farewell/gates/G0.json
    95      0  .keel/specs/farewell/gates/G1.json
    33      0  .keel/specs/farewell/plan.md
    21      0  .keel/specs/farewell/spec.md
    21      0  .keel/specs/farewell/tasks.md
     1      0  src/farewell.txt
     4      0  src/tests/farewell.sh

18 file(s), +317 -1 (318 lines of churn) against 33286299aa95157695c199049797af37a68da747
```

## Gates

| gate | verdict | passed | failed | blocked |
| --- | --- | --- | --- | --- |
| G2.5 | **pass** | 5 | 0 | 0 |
| G2 | **pass** | 9 | 0 | 0 |
| G3 | **pass** | 4 | 0 | 0 |

## The record

`trajectory.jsonl` holds 13 events, one JSON object per line, in sequence order.
429 tokens were put in front of the model across 4 injection(s).

Verify this bundle has not been edited since it was written:

```sh
keel export --verify keel-<run>.tar.gz
```

Every member's SHA-256 is recorded in `manifest.json`.

## Contents

- `README.md` — this file
- `manifest.json` — member hashes
- `2026-09-26-000/` — run metadata, trajectory, gate results, evidence
- `farewell/` — the spec, plan and tasks as agreed
- `steering/` — the durable context the agent was given
