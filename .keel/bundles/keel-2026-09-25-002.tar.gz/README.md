# keel evidence bundle — run 2026-09-25-002

Spec `greeting`, driver `none`, keel 0.9.0.
Started 2026-09-25T16:03:33.565816+02:00, finished 2026-09-25T16:03:33.726594+02:00.

Base commit `4d2aa50a178bb8b141f601b8072a2cd1c657ae5d`.

## What changed

```
     -      -  .keel/bundles/keel-2026-09-25-001.tar.gz
    16      0  .keel/chain.jsonl
     1      1  .keel/keel.toml
     4      0  .keel/lesson-usage.json
     2      0  .keel/runs/2026-09-25-000/evidence/build.txt
    17      0  .keel/runs/2026-09-25-000/evidence/diff-stat.txt
   425      0  .keel/runs/2026-09-25-000/evidence/diff.patch
     2      0  .keel/runs/2026-09-25-000/evidence/lint.txt
    17      0  .keel/runs/2026-09-25-000/evidence/oracles.json
     8      0  .keel/runs/2026-09-25-000/evidence/ratchet.json
     1      0  .keel/runs/2026-09-25-000/evidence/review-test-invalidation.txt
     2      0  .keel/runs/2026-09-25-000/evidence/test.txt
     1      0  .keel/runs/2026-09-25-000/evidence/tree.txt
    36      0  .keel/runs/2026-09-25-000/gates/G2.5.json
    62      0  .keel/runs/2026-09-25-000/gates/G2.json
    31      0  .keel/runs/2026-09-25-000/gates/G3.json
    11      0  .keel/runs/2026-09-25-000/run.json
    15      0  .keel/runs/2026-09-25-000/trajectory.jsonl
     2      0  .keel/runs/2026-09-25-001/evidence/build.txt
    32      0  .keel/runs/2026-09-25-001/evidence/diff-stat.txt
  1168      0  .keel/runs/2026-09-25-001/evidence/diff.patch
     2      0  .keel/runs/2026-09-25-001/evidence/lint.txt
    17      0  .keel/runs/2026-09-25-001/evidence/oracles.json
     8      0  .keel/runs/2026-09-25-001/evidence/ratchet.json
     1      0  .keel/runs/2026-09-25-001/evidence/review-test-invalidation.txt
     2      0  .keel/runs/2026-09-25-001/evidence/test.txt
     1      0  .keel/runs/2026-09-25-001/evidence/tree.txt
    36      0  .keel/runs/2026-09-25-001/gates/G2.5.json
    62      0  .keel/runs/2026-09-25-001/gates/G2.json
    30      0  .keel/runs/2026-09-25-001/gates/G3.json
    11      0  .keel/runs/2026-09-25-001/run.json
    13      0  .keel/runs/2026-09-25-001/trajectory.jsonl
     2      0  .keel/runs/2026-09-25-002/evidence/build.txt
     2      0  .keel/runs/2026-09-25-002/evidence/lint.txt
    17      0  .keel/runs/2026-09-25-002/evidence/oracles.json
     2      0  .keel/runs/2026-09-25-002/evidence/test.txt
     9      0  .keel/runs/2026-09-25-002/run.json
     9      0  .keel/runs/2026-09-25-002/trajectory.jsonl
     3      0  .keel/specs/greeting/approvals.jsonl
    90      0  .keel/specs/greeting/gates/G0.json
    95      0  .keel/specs/greeting/gates/G1.json
    33      0  .keel/specs/greeting/plan.md
     0      0  .keel/specs/greeting/review-flags.txt
    21      0  .keel/specs/greeting/spec.md
    21      0  .keel/specs/greeting/tasks.md
     1      1  src/greeting.txt
     4      0  src/tests/greeting.sh

47 file(s), +2345 -2 (2347 lines of churn) against 4d2aa50a178bb8b141f601b8072a2cd1c657ae5d
```

## Gates

| gate | verdict | passed | failed | blocked |
| --- | --- | --- | --- | --- |
| G2.5 | **pass** | 5 | 0 | 0 |
| G2 | **pass** | 9 | 0 | 0 |
| G3 | **pass** | 4 | 0 | 0 |

## The record

`trajectory.jsonl` holds 13 events, one JSON object per line, in sequence order.
429 tokens were put in front of the model across 4 injection(s).

Verify this bundle has not been edited since it was written:

```sh
keel export --verify keel-<run>.tar.gz
```

Every member's SHA-256 is recorded in `manifest.json`.

## Contents

- `README.md` — this file
- `manifest.json` — member hashes
- `2026-09-25-002/` — run metadata, trajectory, gate results, evidence
- `greeting/` — the spec, plan and tasks as agreed
- `steering/` — the durable context the agent was given
